var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Lista de componentes",url:"annotated.html"},
{text:"Índice dos componentes",url:"classes.html"},
{text:"Componentes membro",url:"functions.html",children:[
{text:"Tudo",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"e",url:"functions.html#index_e"},
{text:"f",url:"functions.html#index_f"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"l",url:"functions.html#index_l"},
{text:"n",url:"functions.html#index_n"},
{text:"p",url:"functions.html#index_p"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"v",url:"functions.html#index_v"}]},
{text:"Funções",url:"functions_func.html",children:[
{text:"g",url:"functions_func.html#index_g"},
{text:"s",url:"functions_func.html#index_s"},
{text:"v",url:"functions_func.html#index_v"}]},
{text:"Variáveis",url:"functions_vars.html",children:[
{text:"a",url:"functions_vars.html#index_a"},
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"d",url:"functions_vars.html#index_d"},
{text:"e",url:"functions_vars.html#index_e"},
{text:"f",url:"functions_vars.html#index_f"},
{text:"i",url:"functions_vars.html#index_i"},
{text:"l",url:"functions_vars.html#index_l"},
{text:"n",url:"functions_vars.html#index_n"},
{text:"p",url:"functions_vars.html#index_p"},
{text:"s",url:"functions_vars.html#index_s"},
{text:"t",url:"functions_vars.html#index_t"},
{text:"v",url:"functions_vars.html#index_v"}]}]}]},
{text:"Ficheiros",url:"files.html",children:[
{text:"Lista de ficheiros",url:"files.html"}]}]}
