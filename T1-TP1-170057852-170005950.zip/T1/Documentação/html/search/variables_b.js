var searchData=
[
  ['tipo_5fde_5facomodacao',['tipo_de_acomodacao',['../class_acomodacao.html#adab84f01949d530189f2c0adce7ec795',1,'Acomodacao']]]
];
