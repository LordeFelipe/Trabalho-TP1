var searchData=
[
  ['validade',['validade',['../class_cartao.html#ae1a286a0fc6cc6f905e25a28aa448633',1,'Cartao']]],
  ['verdadeiro',['VERDADEIRO',['../class_nome.html#a1dc020bbf4d047a398d462a44294b771',1,'Nome::VERDADEIRO()'],['../class_senha.html#a8a8afdc690ff2c5540e062f0ea6c8260',1,'Senha::VERDADEIRO()']]]
];
