var indexSectionsWithContent =
{
  0: "abcdefgilnpstuv",
  1: "abcdeinstuv",
  2: "gsv",
  3: "abcdefilnpstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Funções",
  3: "Variáveis"
};

